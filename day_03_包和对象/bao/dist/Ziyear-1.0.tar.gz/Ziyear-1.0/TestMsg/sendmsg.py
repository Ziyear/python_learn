def test2():
    print("sendmsg------test2")
