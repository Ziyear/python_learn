from distutils.core import setup

setup(name="Ziyear", version="1.0", description="Ziyear's model", author="Ziyear",
      py_modules=['TestMsg.receive', 'TestMsg.sendmsg'])
